// Blockchain SDK for CoinVerse
module.exports = {};