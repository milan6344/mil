// Airdrop routes
module.exports = {};