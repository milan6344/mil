// Airdrop logic
module.exports = {};