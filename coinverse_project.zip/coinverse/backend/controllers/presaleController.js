// Presale logic
module.exports = {};