// Solana blockchain utilities
module.exports = {};