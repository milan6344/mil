// Database utility functions
module.exports = {};