// Authentication middleware
module.exports = {};